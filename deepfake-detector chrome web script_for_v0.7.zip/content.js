// [1] 딱지 부착 함수
function addBadge(imgElement, score) {
  if (imgElement.parentElement.querySelector('.df-badge')) return;
  if (getComputedStyle(imgElement.parentElement).position === 'static') {
      imgElement.parentElement.style.position = 'relative';
  }
  const badge = document.createElement('div');
  badge.className = 'df-badge';
  badge.innerText = `⚠️ 딥페이크 ${score}`;
  imgElement.parentElement.appendChild(badge);
}

// [2] 결과 오버레이 창 표시 함수
function showResultOverlay(result, score, typeText = "분석 결과") {
  const existing = document.querySelector('.df-result-alert');
  if (existing) existing.remove();
  const alertDiv = document.createElement('div');
  alertDiv.className = `df-result-alert ${result === "가짜" ? "fake" : ""}`;
  alertDiv.innerHTML = `
      <h3>${typeText}</h3>
      <p>판별 : <strong>${result}</strong></p>
      <p>신뢰도 점수 : ${score}</p>
      <button id="df-close-btn">닫기</button>`;
  document.body.appendChild(alertDiv);
  document.getElementById('df-close-btn').onclick = () => alertDiv.remove();
}

// [3] 통합 탐지 실행 로직
async function runDetectionFlow(settings) {
  const video = document.querySelector('video.html5-main-video') || document.querySelector('video');

  if (video && video.readyState >= 2) {
      // 영상이 재생 중이 아니면 녹화가 안 될 수 있으므로 체크
      if (video.paused) {
          alert("영상을 재생한 상태에서 탐지를 시작해주세요.");
          return;
      }

      console.log("영상 조각 녹화를 시작합니다 (3초)...");

      const stream = video.captureStream ? video.captureStream() : video.mozCaptureStream();
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp8' }); // 코덱 명시
      const chunks = [];

      mediaRecorder.ondataavailable = (e) => {
          if (e.data.size > 0) chunks.push(e.data);
      };

      mediaRecorder.onstop = async () => {
          if (chunks.length === 0) {
              alert("영상 데이터를 캡처하지 못했습니다.");
              return;
          }

          const videoBlob = new Blob(chunks, { type: 'video/webm' });
          console.log(`녹화 완료: ${videoBlob.size} bytes`); // 로그로 크기 확인

          const reader = new FileReader();
          reader.readAsDataURL(videoBlob);
          reader.onloadend = () => {
              chrome.runtime.sendMessage({
                  action: "PROCESS_UPLOAD",
                  dataUrl: reader.result,
                  filename: "captured_video.webm",
                  isVideo: true
              }, (res) => {
                  if (res && res.success) {
                      showResultOverlay(res.data.result, res.data.ae_score, "영상 분석 결과");
                  } else {
                      alert("서버 분석에 실패했습니다.");
                  }
              });
          };
      };

      mediaRecorder.start();
      setTimeout(() => {
          if (mediaRecorder.state === "recording") mediaRecorder.stop();
      }, 3000); // 3000ms = 3초 녹화

    } else {
        const images = Array.from(document.querySelectorAll('img'));
        const { maxImages, minSize } = settings;
        let processedCount = 0;

        console.log(`탐지 시작: 최소 크기 ${minSize}px, 최대 ${maxImages}개`);

        for (let img of images) {
            // 최대 개수 도달 시 중단
            if (processedCount >= maxImages) break;
            // 사이즈 미달 및 외부 주소가 아닌 이미지 건너뛰기
            if (img.src.startsWith('http') && img.naturalWidth >= minSize && img.naturalHeight >= minSize) {
                processedCount++;
                chrome.runtime.sendMessage({
                    action: "PROCESS_UPLOAD",
                    dataUrl: img.src,
                    filename: `img_${processedCount}.jpg`,
                    isVideo: false
                }, (res) => {
                    if (res && res.data && res.data.result === "가짜") {
                        addBadge(img, res.data.score);
                    }
                });
            }
        }
        if (processedCount === 0) alert(`${minSize}px 이상의 이미지를 찾지 못했습니다.`);
    }
}

// [4] 단일 메시지 리스너
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    console.log("메시지 수신됨:", msg.action);
    if (msg.action === "START_DETECTION_FLOW") {
        runDetectionFlow(msg.settings);
        sendResponse({status: "탐지 프로세스 시작"});
    }
    if (msg.action === "SCAN_RIGHT_CLICKED") {
        chrome.runtime.sendMessage({
            action: "PROCESS_UPLOAD",
            dataUrl: msg.url,
            filename: "context_menu.jpg",
            isVideo: false
        }, (res) => {
            if (res && res.success) {
                showResultOverlay(res.data.result, res.data.score, "이미지 분석 결과");
            }
        });
    }
    return true;
});

let lastDetectedId = null;
const AI_KEYWORDS = [
  "수정되었거나 합성된 콘텐츠", 
  "Altered or synthetic content", 
  "변경되었거나 합성된 콘텐츠",
  "ai영상",
  "aivideo"
];

console.log("🚀 [System] 유튜브 AI 라벨 탐지 엔진 가동 중...");

// 1. 핵심 탐지 로직
function performDetection() {
  const isShorts = location.pathname.startsWith('/shorts/');
  
  if (isShorts) {
    detectShorts();
  } else {
    detectRegularVideo();
  }
}

// 2. 쇼츠 전용 탐지 (강화형)
function detectShorts() {
  // 현재 활성화된 쇼츠 컨테이너 찾기
  const activeShort = document.querySelector('ytd-reel-video-renderer[is-active]');
  if (!activeShort) return;

  const currentId = activeShort.getAttribute('video-id');
  if (lastDetectedId === currentId) return;

  // 쇼츠의 메타데이터 영역 (제목, 채널명 주변) 타겟팅
  // 쇼츠는 라벨이 오버레이 레이어에 렌더링됨
  const overlay = activeShort.querySelector('#overlay');
  if (!overlay) return;

  const textContent = overlay.innerText.toLowerCase().replace(/\s/g, '');
  const isAI = AI_KEYWORDS.some(k => textContent.includes(k.replace(/\s/g, '')));

  if (isAI) {
    lastDetectedId = currentId;
    console.log(`✅ [Shorts 탐지] ID: ${currentId}`);
    triggerAlert();
  }
}

// 3. 일반 영상 탐지
function detectRegularVideo() {
  const currentId = new URLSearchParams(window.location.search).get("v");
  if (!currentId || lastDetectedId === currentId) return;

  // 일반 영상은 설명란이나 정보 블록 확인
  const containers = document.querySelectorAll('ytd-video-description-infoblock-renderer, #description-inline-expander');
  let found = false;

  containers.forEach(c => {
    const text = c.innerText.toLowerCase().replace(/\s/g, '');
    if (AI_KEYWORDS.some(k => text.includes(k.replace(/\s/g, '')))) {
      found = true;
    }
  });

  if (found) {
    lastDetectedId = currentId;
    console.log(`✅ [Video 탐지] ID: ${currentId}`);
    triggerAlert();
  }
}

// 4. 시각적 알림 (화면 상단 고정)
function triggerAlert() {
  // 기존 팝업이 있다면 제거
  const oldPopup = document.getElementById("ai-warning-popup");
  if (oldPopup) oldPopup.remove();

  const div = document.createElement('div');
  div.id = "ai-warning-popup";
  div.style.cssText = `
    position: fixed; top: 100px; left: 50%; transform: translateX(-50%);
    z-index: 999999; background: #ff0000; color: white; padding: 15px 30px;
    border-radius: 50px; font-weight: bold; font-size: 20px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.6); border: 3px solid white;
    pointer-events: none; transition: opacity 0.5s;
  `;
  div.innerHTML = "⚠️ AI 생성 콘텐츠 주의!";
  document.body.appendChild(div);
  
  setTimeout(() => {
    div.style.opacity = "0";
    setTimeout(() => div.remove(), 5000);
  }, 6000);
}

// 5. 실행 엔진 (성능 최적화)
// MutationObserver가 attribute 변화(is-active)도 감지하도록 설정
const observer = new MutationObserver((mutations) => {
  for (let mutation of mutations) {
    // 쇼츠 전환 시 속성 변화를 즉각 포착
    if (mutation.type === 'attributes' || mutation.type === 'childList') {
      performDetection();
    }
  }
});

observer.observe(document.body, { 
  childList: true, 
  subtree: true, 
  attributes: true, 
  attributeFilter: ['is-active'] 
});

// 유튜브의 SPA 전환 이벤트 대응
window.addEventListener('yt-navigate-finish', () => {
  lastDetectedId = null;
  // 데이터 로딩 시간을 벌기 위해 0.5초 간격으로 3번 재시도
  [500, 1500, 3000].forEach(delay => setTimeout(performDetection, delay));
});

console.log("Deepfake Detector 스크립트 로드 완료");